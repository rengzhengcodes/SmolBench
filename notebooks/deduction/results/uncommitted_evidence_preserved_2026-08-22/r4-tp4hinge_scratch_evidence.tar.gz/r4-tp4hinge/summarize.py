"""Renders tp4hinge_<model>.json into the per-arm deliverable (k/8 + prefixes)."""
import json, pathlib, sys

p = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else
                 pathlib.Path(__file__).with_name("tp4hinge_ministral-3-3b.json"))
r = json.loads(p.read_text())
print(f"model={r['model']} type={r['type']} expect_tp={r['expect_tp']} "
      f"prompts_match_tp1={r.get('prompt_set_matches_tp1_hinge')}")
inst = r.get("instance", {})
print(f"instance={inst.get('instance_id')} {inst.get('instance_type')} @ {inst.get('availability_zone')}")
for arm, e in r.get("arms", {}).items():
    print(f"\n--- arm {arm} ---")
    if e.get("skipped_for_budget_at_min"):
        print(f"  SKIPPED for budget at {e['skipped_for_budget_at_min']} min"); continue
    if e.get("FAILED"):
        print(f"  FAILED: {e['FAILED']}")
    cfg = e.get("server_config") or {}
    print(f"  served_tp={e.get('served_tp')} gpu={cfg.get('gpu')} "
          f"vllm={cfg.get('vllm_version')} backend={cfg.get('attention_backend')}")
    print(f"  args={e.get('vllm_args')}")
    print(f"  serve+passes_s={e.get('serve_plus_passes_s')}")
    for i in (1, 2):
        if e.get(f"retried_rows_P{i}"):
            print(f"  retried_rows_P{i}: {e[f'retried_rows_P{i}']}")
    c = e.get("within_process_baseline")
    if not c:
        print("  (no comparison recorded)"); continue
    print(f"  WITHIN-PROCESS: {c['identical']}/{c['n']} byte-identical "
          f"(rate {c['rate']:.3f}); excluded-empty={c['excluded_empty_rows']}; "
          f"n_before_exclusion={c['n_before_exclusion']}")
    for d in c["diffs"]:
        print(f"    DIFF {d['prompt']}: len {d['len_a']} vs {d['len_b']}, "
              f"sha {d['sha_a']} vs {d['sha_b']}, common_prefix={d['common_prefix_chars']}")
    if not c["diffs"]:
        st = e.get("sha_table_P1", {})
        for k, v in st.items():
            print(f"    SAME {k}: sha={v['sha256_12']} len={v['len']}")
