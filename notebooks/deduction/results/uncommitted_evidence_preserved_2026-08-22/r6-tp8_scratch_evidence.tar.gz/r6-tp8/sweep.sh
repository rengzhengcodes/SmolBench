#!/bin/bash
set -a; . /workspace/SmolBench/notebooks/ec2-operator.env; set +a
for r in us-east-1 us-east-2 us-west-2; do echo "== $r $(date -u)";
 aws ec2 describe-instances --region $r --filters "Name=instance-state-name,Values=pending,running,shutting-down,stopping,stopped" \
  --query 'Reservations[].Instances[].[InstanceId,InstanceType,State.Name,LaunchTime,Tags[?Key==`smolbench:experiment`]|[0].Value]' --output text; done
