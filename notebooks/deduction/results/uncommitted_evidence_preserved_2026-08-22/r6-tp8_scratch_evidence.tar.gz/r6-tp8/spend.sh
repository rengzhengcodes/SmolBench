#!/bin/bash
# Actual-price spend tracker: for every harness-tagged instance in the three
# regions, report launch time, state, and the CURRENT spot price in its AZ.
set -a; . /workspace/SmolBench/notebooks/ec2-operator.env; set +a
now=$(date -u +%s)
for r in us-east-1 us-east-2 us-west-2; do
  aws ec2 describe-instances --region $r \
    --filters "Name=tag-key,Values=smolbench:experiment" \
    --query 'Reservations[].Instances[].[InstanceId,InstanceType,State.Name,LaunchTime,Placement.AvailabilityZone,Tags[?Key==`smolbench:experiment`]|[0].Value]' \
    --output text 2>/dev/null | while read -r id itype st lt az tag; do
      [ -z "$id" ] && continue
      case "$tag" in tp8hinge*) ;; *) continue;; esac
      lts=$(date -u -d "$lt" +%s)
      hrs=$(python3 -c "print(round(($now-$lts)/3600,3))")
      px=$(aws ec2 describe-spot-price-history --region $r --instance-types $itype \
            --availability-zone $az --product-descriptions "Linux/UNIX" \
            --start-time "$(date -u +%Y-%m-%dT%H:%M:%S)" \
            --query 'SpotPriceHistory[0].SpotPrice' --output text 2>/dev/null)
      python3 -c "print(f'$r $id $itype $st $az launched=$lt hrs=$hrs px=$px cost=\${float(\"$px\")*float(\"$hrs\"):.2f}')"
    done
done
