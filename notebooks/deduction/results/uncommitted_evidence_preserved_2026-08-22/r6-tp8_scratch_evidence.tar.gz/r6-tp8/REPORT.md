# PACKAGE tp8-hinge — the last uncertified determinism case

STATUS: IN PROGRESS (written incrementally; RESULTS authoritative only where MEASURED).

Date 2026-08-21/22 UTC. Repo /workspace/SmolBench, branch periodic-induction,
HEAD at start f9a3e5db. Budget cap $80, wall cap 6h from 21:31 UTC (deadline 03:31 UTC).

## What was uncertified

Bundle = `--no-enable-prefix-caching --max-num-seqs 1 --enforce-eager --seed 0`
plus digest/revision pins. Prior certification:

| tp | date | box | result |
|----|------|-----|--------|
| 1 | 2026-08-16 | g6e.4xlarge, 1x L40S | 8/8 byte-identical within process (nemotron-3-nano-4b, ministral-3-3b); stock 0/8 |
| 4 | 2026-08-21 | g6e.12xlarge, 4x L40S PCIe | 8/8 both models; stock control 1/4 (3/3 divergent as-drawn) |
| 8 | THIS PACKAGE | p5.48xlarge, 8x H100 80GB NVLink/NVSwitch | see RESULTS |

Nine deploy specs serve at tp=8 (qwen3.5-397b-a17b, qwen3.5-122b-a10b,
nemotron-3-super-120b-a12b, k-exaone-236b-a23b, glm-4.5-air, glm-4.7,
deepseek-v3.1, deepseek-v4-flash, deepseek-v4-pro) — every one an MoE. Two
mechanisms are new at tp=8 and unexercised by tp=1/tp=4:

1. **Custom all-reduce.** vLLM picks a hand-written NVLink all-reduce when P2P
   is available across all ranks. The g6e boxes of tp=1/tp=4 are PCIe-only and
   fall back to NCCL, so that kernel has never run in any certified arm.
2. **MoE routing at 8-way TP.** No spec sets `--enable-expert-parallel`, so
   experts are TP-sharded; deliberately NOT added here (off-protocol).

## Method

`scripts/tp8_hinge_probe.py` — a **copy** of `scripts/tp4_hinge_probe.py`, not a
reuse. Reusing in place would have been destructive: it derives `report_path`,
the gz text archives, `EC2_EXPERIMENT_TAG` and `EC2_STATE_FILE` from a hardcoded
`tp4` string, loads the existing report, and skips every arm already stamped
`complete: true` — so an `--expect-tp 8` invocation would have measured nothing
and relabelled the tp=4 record as tp=8.

Protocol unchanged from tp=1/tp=4: same deterministically-selected real deduction
prompts from the model's own S3 run dir, temperature 0.7, seed 0, max_tokens
32768, streaming transport, two back-to-back passes within ONE server process,
byte-compared. Pre-committed rules inherited: tp gate asserted from the recorded
launch payload before any prompt is sent; rows of length <= 1 are a transport
fault (re-asked once) and excluded rather than counted as divergence; arm-level
checkpoints.

Additions over the tp=4 probe:

* **Unconditional serve-log capture + topology grep** (tp=4 fetched the serve log
  only in its `except` branch, so a *successful* arm recorded nothing about which
  all-reduce implementation vLLM chose — the load-bearing fact for this package).
* **SHA-level tp=4-vs-tp=8 cross comparison** (tp=4 JSONs store `sha_table_P1/P2`
  for all rows; the tp=4 report could only compare lengths against tp=1).
* **Row-by-row persistence and pass deadlines.** Each completed row is written to
  the report and gz archive immediately; no new prompt after a wall deadline; P2
  runs over exactly the prompt ids P1 completed, so a truncated arm reports k/k
  over a smaller k rather than a spurious divergence.
* **DET_ARGS equality guard**: aborts if `ec2.DETERMINISM_ARGS` drifts from the
  probe's list, which would silently leave determinism flags in the *stock* arm.

## Scope constraint on the cross-tp comparison

tp=4 ran on L40S, tp=8 on H100. GPU model and tp change together. Any
tp4-vs-tp8 disagreement is a cross-CONFIG fact consistent with the existing
cross-config pooling guard — NOT evidence about tensor-parallel degree alone.

## RESULTS

### Box 1 — i-03ed51f2b12061e4c, p5.48xlarge, us-east-2a, spot $19.9802/h

Launched 2026-08-21T21:34:51Z. Control agent up 21:36:33 (102 s). vLLM serving
21:40:06 (3.5 min from serve request — the S3 hub-cache mirror, not HF).

**tp GATE PASSED** — `tp=8`, `8x H100 80GB`, vLLM `0.27.2rc1.dev122+g8efa13b70`.

#### Topology evidence (MEASURED, `tp8_topology_evidence.json`)

Pulled live from the agent's authenticated `GET /status` → `log_tail`
(`docker logs --tail 300 vllm`):

```
tensor_parallel_size      = 8
pipeline_parallel_size    = 1
disable_custom_all_reduce = False    <-- custom all-reduce ENABLED
enforce_eager             = True
enable_prefix_caching     = False
seed                      = 0
dtype                     = torch.bfloat16
worker ranks              = Worker_TP0 .. Worker_TP7   (all 8 real)
compilation mode          = CompilationMode.NONE
cudagraph_mode            = CUDAGraphMode.NONE
custom fusions enabled    = norm_quant, act_quant, allreduce_rms
                            ('fuse_allreduce_rms': True)
```

So the arm is **not** a tp=8 label over a tp=1 reality, and the NVLink custom
all-reduce path is not disabled — the two things this package existed to
establish. Revision pin verified applied from the `non-default args` line
(`revision=4a36357c...`, `tokenizer_revision=4a36357c...`); the later
`revision=main` in the engine-config echo is a display quirk of the model
config repr, not the effective value.

#### THREE BUGS FOUND IN THE INHERITED PROBE (fixed in the tp=8 copy)

The first serve-log capture came back **empty**. Root cause, found live:

1. The control agent's `/status` is Bearer-token gated; the tp=4 probe's
   `requests.get` sent no `Authorization` header, so every such call returned
   HTTP 401 `{"error": "bad token"}`. **`hinge_probe.fingerprint()` has the
   same defect** — its `image_digest_lines` are empty in every archived hinge
   report because of a 401, not because the box was quiet.
2. `serve_log_tail` is the *launcher script's* stdout (`aws s3 sync` +
   `docker run -d`). vLLM's own banner — the only place tp / all-reduce /
   eager / seed appear — is in `log_tail`.
3. It was called only from the `except` branch, so a successful arm recorded
   nothing at all.

#### det@tp8 (ministral-3-3b) — measurement in flight

Throughput calibration (single row, do not over-read): row 1
(`AlgHom.fieldRange_of_normal/hint-2`) produced 93,555 chars in 580 s
= 161 chars/s. The tp=4 det arm's aggregate was 646,064 chars over 4,383 s
= 147 chars/s (serve time included). **These are the same number within
noise** — nothing here says tp=8 eager on H100 is faster or slower per token
than tp=4 eager on L40S. Wall-clock cost per arm, not per-token rate, is what
drove the budget planning.

Cache counters were captured correctly (the `/metrics` probe uses the vLLM API
key on port 8000 and is unaffected by the 401 defect):
`vllm:prefix_cache_queries_total 0.0`, `vllm:prefix_cache_hits_total 0.0`,
`cache_config_info{enable_prefix_caching="False", block_size="16",
num_gpu_blocks="360992", kv_cache_size_tokens="5775872",
gpu_memory_utilization="0.92"}` — i.e. the cache is genuinely off, so the
within-process agreement cannot be prefix-cache replay (the exact confound the
2026-08-16 hinge existed to rule out at tp=1).


## SPEND
(pending)

## TEARDOWN
(pending)
