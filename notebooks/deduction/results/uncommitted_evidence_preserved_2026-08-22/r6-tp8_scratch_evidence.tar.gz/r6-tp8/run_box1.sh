set -a; . /workspace/SmolBench/notebooks/ec2-operator.env; . /workspace/SmolBench/notebooks/deduction/keys.env; set +a
unset EC2_EXPERIMENT_TAG
export EC2_ROOT_VOLUME_GB=300
export EC2_MAX_LIFETIME_MIN=125
cd /workspace/SmolBench
exec .venv/bin/python scripts/tp8_hinge_probe.py \
  --model ministral-3-3b --arms det,stock --control-n 4 \
  --n-prompts 8 --expect-tp 8 \
  --pass-deadline-min 78 --p2-grace-min 28 \
  --deadline-min 100 --arm-start-latest-min 85
