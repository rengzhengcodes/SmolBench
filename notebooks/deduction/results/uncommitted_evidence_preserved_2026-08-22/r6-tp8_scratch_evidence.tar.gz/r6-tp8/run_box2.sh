set -a; . /workspace/SmolBench/notebooks/ec2-operator.env; . /workspace/SmolBench/notebooks/deduction/keys.env; set +a
unset EC2_EXPERIMENT_TAG
export EC2_ROOT_VOLUME_GB=500
export EC2_MAX_LIFETIME_MIN=${FUSE:-110}
cd /workspace/SmolBench
exec .venv/bin/python scripts/tp8_hinge_probe.py \
  --model nemotron-3-super-120b-a12b --arms det \
  --n-prompts ${NP:-4} --expect-tp 8 \
  --pass-deadline-min ${PD:-62} --p2-grace-min ${PG:-32} \
  --deadline-min ${DL:-95} --arm-start-latest-min 1
