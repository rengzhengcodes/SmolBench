#!/bin/bash
# r5/postcut.sh with every WRITE repointed from $R5_DIR to $R6_DIR: r5's copies
# are the committed leg-2 provenance record and must survive this run intact.
set -e
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/env.sh
cd /workspace/SmolBench
D=notebooks/deduction/results/runs/flip2_nemotron-3-nano-4b
echo "=== 1. purge exception rows (backup first, into R6) ==="
.venv/bin/python - <<PY
import json, gzip, shutil, pathlib, sys
sys.path.insert(0,"scripts")
from smolbench.deduction.lean import runner
R6=pathlib.Path("$R6_DIR")
src=pathlib.Path("$D/all_rows.jsonl")
with open(src,"rb") as f, gzip.open(R6/"all_rows_leg2_full_raw.jsonl.gz","wb") as g:
    shutil.copyfileobj(f,g)
rows=[json.loads(l) for l in open(src) if l.strip()]
keep=[r for r in rows if not (r.get("kind")=="cell" and r.get("verdict")=="exception")]
with open(src,"w") as f:
    for r in keep: f.write(json.dumps(r, ensure_ascii=False)+"\n")
cells=[r for r in keep if r.get("kind")=="cell"]
key=lambda r: list(runner._row_key(r.get("model",""), r.get("theorem_id",""), int(r.get("k",-1)), r.get("rung",""), int(r.get("replicate_idx",-1))))
(R6/"keys_full.json").write_text(json.dumps([key(r) for r in cells], indent=1)+"\n")
print("purged", len(rows)-len(keep), "exception rows; real cells:", len(cells))
PY
echo "=== 2. spool purged run to S3 (flip2 prefix) ==="
.venv/bin/python $R6_DIR/r6_driver.py spool
echo "=== 3. leg (a): verify the rerun rows ==="
.venv-lean/bin/python $R6_DIR/r6_driver.py lega --workers 3
echo "=== 4. flip_probe's own analyze (leg 2, FULL 200-cell whitelist) ==="
.venv/bin/python $R6_DIR/r6_driver.py analyze
echo "=== 5. pooled analysis (byte-identical estimator; OUT=R6) ==="
.venv/bin/python $R6_DIR/pool_analyze.py $R6_DIR
cp $R6_DIR/regime_mean_report.json $R6_DIR/regime_mean_report_full.json
echo "=== 6. per-process split ==="
.venv/bin/python $R6_DIR/by_process.py
