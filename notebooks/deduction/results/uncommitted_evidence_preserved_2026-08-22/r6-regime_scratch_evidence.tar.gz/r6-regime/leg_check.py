"""Advisor item 3: prove leg 2 actually loads 200 pairs BEFORE anything is pooled.

The 311-cell draw was not produced by an error -- it was produced by
`load_leg` silently dropping whole theorems under the complete-theorem rule.
The only way to know the merge landed is to run that same loader and require
zero missing cells and zero dropped theorems.
"""
import json, sys, pathlib
R6 = "/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime"
sys.path.insert(0, R6)
import pool_analyze as pa

out = {}
for name, run in (("leg1", "flip_nemotron-3-nano-4b"), ("leg2", "flip2_nemotron-3-nano-4b")):
    leg, _ = pa.load_leg(run)
    out[name] = {
        "n_whitelist": leg["n_whitelist"], "n_pairs": len(leg["pairs"]),
        "n_missing": len(leg["missing"]), "missing_sample": [list(k) for k in leg["missing"][:5]],
        "n_theorems_dropped": len(leg["dropped_theorems"]),
        "empty_rerun_candidate_proof": leg["empty_rerun_candidate_proof"],
    }
print(json.dumps(out, indent=2))
pathlib.Path(R6, "leg_check.json").write_text(json.dumps(out, indent=2) + "\n")
l2 = out["leg2"]
# EXPECTED: 199 pairs. Exactly one whitelisted cell is unmeasurable --
# colimit_sound k=0 stepk:1, whose 110920-char runaway candidate crashes Dojo
# deterministically -- so `load_leg` moves it to `missing` and the
# complete-theorem rule drops that single-cell theorem. Anything OTHER than
# 199/1/1 means the merge did not land the way it was audited to.
EXPECT = {"n_pairs": 199, "n_missing": 1, "n_theorems_dropped": 1}
got = {k: l2[k] for k in EXPECT}
if got != EXPECT:
    raise SystemExit(f"LEG CHECK FAILED: leg2 {got}, expected {EXPECT}. Do NOT pool.")
if l2["missing_sample"][0][1] != "CategoryTheory.Limits.Types.colimit_sound":
    raise SystemExit(f"LEG CHECK FAILED: unexpected missing cell {l2['missing_sample']}")
print("LEG CHECK PASSED: leg2 = 199/200 pairs; the 1 drop is the audited Dojo-crash cell.")
