"""Per-PROCESS split of the regime-mean draw.

The estimand of section 6.2/7.2 is cross-PROCESS variation, so the draw is only
interpretable if the shift does not depend on which serving process produced the
rerun. Cell rows carry no timestamp, so processes are identified by the key
SNAPSHOTS taken as each box died:

  leg1  / box0  2026-08-18 g6e.2xlarge us-west-2a   -- the whole leg-1 whitelist
  leg2a / box1+2 2026-08-21 g6e.4xlarge us-east-2a/b -- r5/keys_before_box3.json
  leg2b / box3  2026-08-21 g6e.2xlarge us-east-1d   -- r5/keys_final.json minus the above
  leg2c / box4  2026-08-21 (this run)               -- r6/keys_full.json minus keys_final

Each stratum reuses pool_analyze's own `stats()` -- same estimator, same cluster
bootstrap, same seed -- so the strata and the pooled headline are commensurable.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

R5 = Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime")
R6 = Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime")
sys.path.insert(0, str(R6))
import pool_analyze as pa  # noqa: E402


def keyset(p: Path) -> set[tuple]:
    return {tuple(k) for k in json.loads(p.read_text())}


def main() -> None:
    leg1, _ = pa.load_leg("flip_nemotron-3-nano-4b")
    leg2, _ = pa.load_leg("flip2_nemotron-3-nano-4b")

    b12 = keyset(R5 / "keys_before_box3.json")
    b123 = keyset(R5 / "keys_final.json")
    b1234 = keyset(R6 / "keys_full.json") if (R6 / "keys_full.json").exists() else b123
    strata = {
        "leg1_box0_20260818_g6e2xl_usw2a": {
            "pairs": leg1["pairs"],
            "box": "i-078685504837ee403 g6e.2xlarge us-west-2a",
        },
        "leg2a_box1_2_20260821_g6e4xl_use2": {
            "pairs": {k: v for k, v in leg2["pairs"].items() if k in b12},
            "box": "i-0d8cdce6fbadbf47e + i-0a10fa46caefa5c08 g6e.4xlarge us-east-2a/b",
        },
        "leg2b_box3_20260821_g6e2xl_use1d": {
            "pairs": {k: v for k, v in leg2["pairs"].items() if k in b123 - b12},
            "box": "i-09bae6dd10977ea5c g6e.2xlarge us-east-1d",
        },
        "leg2c_box4_20260821_completion": {
            "pairs": {k: v for k, v in leg2["pairs"].items() if k in b1234 - b123},
            "box": json.loads((R6 / "box4.json").read_text())["desc"]
            if (R6 / "box4.json").exists() else "this run",
        },
    }
    out = {}
    keep = ("n", "n_theorems", "a_both_pass", "b_orig_pass_rerun_fail",
            "c_orig_fail_rerun_pass", "d_both_fail", "flip_rate", "pass1_orig",
            "pass1_rerun", "mean_shift_pts", "mean_shift_se_naive_pts",
            "mean_shift_boot_se_pts", "mean_shift_ci95_cluster_boot_pts",
            "mcnemar_exact_p")
    for name, s in strata.items():
        if not s["pairs"]:
            out[name] = {"box": s["box"], "n": 0, "note": "no cells in this stratum"}
            continue
        st = pa.stats(s["pairs"])
        out[name] = {"box": s["box"], **{k: st[k] for k in keep}}

    # Between-process homogeneity: chi-square on the per-stratum shifts about
    # their inverse-variance-weighted mean (bootstrap SEs, so clustering is in).
    pts = [(v["mean_shift_pts"], v["mean_shift_boot_se_pts"])
           for v in out.values() if v.get("n", 0) > 0 and v.get("mean_shift_boot_se_pts", 0) > 0]
    if len(pts) > 1:
        w = [1 / se ** 2 for _, se in pts]
        mu = sum(wi * m for wi, (m, _) in zip(w, pts)) / sum(w)
        Q = sum(wi * (m - mu) ** 2 for wi, (m, _) in zip(w, pts))
        df = len(pts) - 1
        # survival of chi2 via regularized upper incomplete gamma (series/CF)
        try:
            from statistics import NormalDist  # noqa: F401
            import scipy.stats as ss  # type: ignore
            p = float(ss.chi2.sf(Q, df))
        except Exception:
            # Wilson-Hilferty normal approximation -- adequate for a homogeneity check
            z = ((Q / df) ** (1 / 3) - (1 - 2 / (9 * df))) / math.sqrt(2 / (9 * df))
            from statistics import NormalDist
            p = 1 - NormalDist().cdf(z)
        out["_homogeneity"] = {
            "k_processes": len(pts), "weighted_mean_shift_pts": mu,
            "Q": Q, "df": df, "p": p,
            "note": "H0: all serving processes share one mean shift",
        }
    (R6 / "by_process_full.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
