"""Verify the 88 completion cells in ISOLATION, then merge.

Why not `verify_run` against the run dir (postcut step 3, which crashed):

1. INDEX MISALIGNMENT. verify_run seeds `out_rows = verified_rows` (243 rows
   from r5's pass) but computes `pending` indices against the NEW all_rows.jsonl
   (331 rows). The 88 appended cells live at indices >= 243, so `fan_out_verdict`
   raised IndexError. Its own docstring invariant ("a prior upload never
   reorders or removes anything") holds only while all_rows.jsonl is frozen
   after a verification pass; this package appended a second generation pass to
   it. Verified: the first 243 positions ARE aligned (0 mismatches), and the run
   crashed before its first checkpoint upload, so verified_rows.jsonl is
   byte-identical to backup_pre_r6 (sha 12e06467...). Nothing was corrupted.

2. RESUME-BY-GROUP WOULD SILENTLY SKIP A CELL. `resume_done_groups` marks a
   whole (theorem_id, k) group done if ANY of its cells has a verdict. Exactly
   one new cell -- ('Prod.swap_iInf', k=0, 'hint:2') -- shares a group r5
   already finished, which is why the run reported 87 pending cell rows for 88
   new cells. That cell would have stayed `unverified` forever, and the
   complete-theorem rule would have dropped its theorem with no error raised.

The fix uses the SAME pattern the pre-spend drift gate already proved on this
machine today: a rows file containing only what we want verified, a
`_LocalRunClient` pointed at a scratch dir outside the run dir, then an explicit
merge. Verifier, workers and env are unchanged, so the verdicts are produced by
the same verifier that graded legs 1 and 2.
"""
import json, sys, pathlib, collections
sys.path.insert(0, "/workspace/SmolBench"); sys.path.insert(0, "/workspace/SmolBench/scripts")
import flip_probe as fp
from smolbench.deduction.lean import runner

R6 = pathlib.Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime")
D = pathlib.Path("/workspace/SmolBench/notebooks/deduction/results/runs/flip2_nemotron-3-nano-4b")

lvr = fp._load_lean_verify_rows()
lvr.require_py312()
mem = pathlib.Path("/proc/meminfo")
WORKERS = 3
if mem.exists():
    lvr.check_workers(WORKERS, mem.read_text())

def key(r):
    return runner._row_key(r.get("model", ""), r.get("theorem_id", ""), int(r.get("k", -1)),
                           r.get("rung", ""), int(r.get("replicate_idx", -1)))

want = set(runner.load_cell_whitelist(str(R6 / "whitelist_missing.json")))
all_rows = [json.loads(l) for l in (D / "all_rows.jsonl").read_text().splitlines() if l.strip()]
ver_rows = [json.loads(l) for l in (D / "verified_rows.jsonl").read_text().splitlines() if l.strip()]
already = {key(r) for r in ver_rows if r.get("kind") == "cell"}

new_cells = [r for r in all_rows if r.get("kind") == "cell" and key(r) in want]
assert len(new_cells) == 88, len(new_cells)
assert not (want & already), "a completion cell is already in verified_rows -- STOP"
assert all(r.get("verdict") == "unverified" for r in new_cells)

ths = {r["theorem_id"] for r in new_cells}
sanity = [dict(r) for r in all_rows if r.get("kind") == "sanity" and r.get("theorem_id") in ths]
print(f"verifying {len(new_cells)} cells over {len(ths)} theorems ({len(sanity)} sanity rows)")

work = R6 / "rerun_new"
work.mkdir(exist_ok=True)
# Restore point FIRST: it must exist no matter where this dies, including
# between the append below and the read-back that follows it.
(R6 / "verified_rows_before_merge.jsonl").write_bytes((D / "verified_rows.jsonl").read_bytes())
rows_path = work / "new_all_rows.jsonl"
verified_path = work / "new_verified_rows.jsonl"
payload = [dict(r) for r in new_cells] + sanity
new_bytes = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in payload).encode()
rows_path.write_bytes(new_bytes)
# UNCONDITIONAL no_resume: a re-run after a partial pass must NOT inherit
# verify_run's group-level resume rule -- that is precisely the rule that
# would skip ('Prod.swap_iInf', k=0, 'hint:2'). 88 cells is a ~5-minute job,
# so re-verifying everything is far cheaper than the hazard.
no_resume = True

client = fp._LocalRunClient(rows_path=rows_path, verified_path=verified_path,
                            rows_filename=lvr.ROWS_FILENAME, verified_filename=lvr.VERIFIED_FILENAME)
with lvr._dojo_cache_lock():
    rc = lvr.verify_run(client=client, bucket="local-completion", key_prefix="", run="_scratch",
                        workers=WORKERS, workdir=work, no_resume=no_resume)
if rc != 0:
    raise SystemExit(f"verify_run rc={rc}")

out = [json.loads(l) for l in verified_path.read_text().splitlines() if l.strip()]
cells = {key(r): r for r in out if r.get("kind") == "cell"}
missing = sorted(want - set(cells))
counts = collections.Counter(r.get("verdict") for k, r in cells.items())
bad = [k for k, r in cells.items() if r.get("verdict") in ("unverified", "exception", "replay_failed")]
print("verdicts:", dict(counts))
if missing:
    raise SystemExit(f"{len(missing)} completion cells absent from the verified output: {missing[:5]}")
if bad:
    raise SystemExit(f"{len(bad)} completion cells did not grade cleanly: {bad[:5]}")

# MERGE: append the 88 graded cells. Keys are disjoint from the 112 already
# there, so pool_analyze's earliest-wins-among-surviving dedupe is unambiguous.
# Sanity rows are NOT appended -- all 131 are already verified in the run dir
# and pool_analyze reads only kind == "cell".
with open(D / "verified_rows.jsonl", "a") as f:
    for k in sorted(want):
        f.write(json.dumps(cells[k], ensure_ascii=False) + "\n")
after = [json.loads(l) for l in (D / "verified_rows.jsonl").read_text().splitlines() if l.strip()]
ac = [r for r in after if r.get("kind") == "cell"]
print(f"merged: verified_rows.jsonl now {len(after)} rows, {len(ac)} cells, "
      f"{len({key(r) for r in ac})} distinct")
(R6 / "verify_new_result.json").write_text(json.dumps({
    "n_verified": len(cells), "verdict_counts": dict(counts),
    "n_cells_after_merge": len(ac), "n_distinct_after_merge": len({key(r) for r in ac}),
}, indent=2) + "\n")
