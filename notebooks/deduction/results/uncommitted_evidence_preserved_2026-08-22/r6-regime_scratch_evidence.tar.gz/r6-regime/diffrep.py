import json
a = json.load(open("/workspace/SmolBench/notebooks/deduction/results/runs/flip2_nemotron-3-nano-4b/flip_report.json"))
b = json.load(open("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/backup_pre_r6/flip_report.json"))


def flat(d, p=""):
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            out.update(flat(v, p + "/" + str(k)))
    elif isinstance(d, list):
        out[p] = json.dumps(d)[:200]
    else:
        out[p] = d
    return out


fa, fb = flat(a), flat(b)
diff = {k: (fb.get(k), fa.get(k)) for k in set(fa) | set(fb) if fa.get(k) != fb.get(k)}
print("n keys differing:", len(diff))
print(json.dumps(diff, indent=2)[:2000])
