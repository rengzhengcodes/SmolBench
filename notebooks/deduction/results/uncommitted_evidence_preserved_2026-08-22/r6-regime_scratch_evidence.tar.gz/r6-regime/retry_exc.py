"""Retry the completion cells that came back `exception`.

One cell graded `DojoCrashError: Unexpected EOF` -- a Dojo/subprocess crash,
which lean_verify_rows maps to `exception` = infrastructure, not a measurement.
The theorem's own ground-truth sanity replay SUCCEEDED (1/1 tactics), so the
theorem and the corpus are fine; the candidate is a 110KB runaway generation
that plausibly killed the subprocess. A retry is legitimate because the rule
being applied (`load_leg`: rerun exception -> missing) discards the cell either
way -- retrying can only recover a real measurement, never manufacture one.

Isolated, single-cell, no resume; result is merged back into the scratch
verified file only if it grades cleanly.
"""
import json, sys, pathlib, collections
sys.path.insert(0, "/workspace/SmolBench"); sys.path.insert(0, "/workspace/SmolBench/scripts")
import flip_probe as fp
from smolbench.deduction.lean import runner

R6 = pathlib.Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime")
work = R6 / "rerun_new"
lvr = fp._load_lean_verify_rows(); lvr.require_py312()

def key(r):
    return runner._row_key(r.get("model", ""), r.get("theorem_id", ""), int(r.get("k", -1)),
                           r.get("rung", ""), int(r.get("replicate_idx", -1)))

vp = work / "new_verified_rows.jsonl"
rows = [json.loads(l) for l in vp.read_text().splitlines() if l.strip()]
bad = [r for r in rows if r.get("kind") == "cell"
       and r.get("verdict") in ("exception", "replay_failed", "unverified")]
if not bad:
    print("nothing to retry"); raise SystemExit(0)
print("retrying:", [(r["theorem_id"], r["k"], r["rung"]) for r in bad])

ths = {r["theorem_id"] for r in bad}
sanity = [dict(r) for r in rows if r.get("kind") == "sanity" and r["theorem_id"] in ths]
fresh = []
for r in bad:
    n = dict(r); n["verdict"] = "unverified"; n["lean_error"] = None; n["final_state_pp"] = None
    fresh.append(n)

rt = work / f"retry{sys.argv[1] if len(sys.argv) > 1 else '1'}"
rt.mkdir(exist_ok=True)
rows_path, verified_path = rt / "rows.jsonl", rt / "verified.jsonl"
rows_path.write_bytes("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in fresh + sanity).encode())
client = fp._LocalRunClient(rows_path=rows_path, verified_path=verified_path,
                            rows_filename=lvr.ROWS_FILENAME, verified_filename=lvr.VERIFIED_FILENAME)
with lvr._dojo_cache_lock():
    rc = lvr.verify_run(client=client, bucket="local-retry", key_prefix="", run="_scratch",
                        workers=1, workdir=rt, no_resume=True)
if rc != 0:
    raise SystemExit(f"retry verify_run rc={rc}")

out = {key(r): r for r in (json.loads(l) for l in verified_path.read_text().splitlines() if l.strip())
       if r.get("kind") == "cell"}
print("retry verdicts:", dict(collections.Counter(r.get("verdict") for r in out.values())))
for k, r in out.items():
    print(" ", k[1], k[2], k[3], "->", r.get("verdict"), (r.get("lean_error") or "")[:120])

good = {k: r for k, r in out.items()
        if r.get("verdict") not in ("exception", "replay_failed", "unverified")}
if good:
    merged = [good.get(key(r), r) if r.get("kind") == "cell" else r for r in rows]
    vp.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in merged))
    print(f"merged {len(good)} recovered cell(s) into {vp.name}")
else:
    print("NO cell recovered on this retry")
