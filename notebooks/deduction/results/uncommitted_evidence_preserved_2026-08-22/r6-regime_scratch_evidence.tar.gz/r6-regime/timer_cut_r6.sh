#!/bin/bash
# ABSOLUTE wall-clock cut (not sleep-from-launch): the analysis tail needs a
# guaranteed hour, and a partial sweep is fully usable because pool_analyze's
# complete-theorem rule drops half-finished theorems cleanly.
# SIGINT (not SIGTERM): CPython raises KeyboardInterrupt so _stage_generate's
# `finally: ec2.shutdown_instance()` RUNS. SIGTERM would leak the box.
DEADLINE=$1
while [ "$(date -u +%s)" -lt "$DEADLINE" ]; do
  pgrep -f "r6_driver.py generate" >/dev/null || { echo "generate already gone $(date -u)"; exit 0; }
  sleep 20
done
echo "CUT at $(date -u)"
pkill -INT -f "r6_driver.py generate"
sleep 150
pgrep -af "r6_driver.py generate" && { echo "still alive; SIGINT again"; pkill -INT -f "r6_driver.py generate"; sleep 90; }
pgrep -af "r6_driver.py generate" || echo "generate process gone $(date -u)"
