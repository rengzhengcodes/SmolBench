"""CONTENT gate on the RERUN side of the 88 completion cells (advisor item 1).

Row/key counts certified a lane that had lost 93.8% of its cells once already;
this gate reads verdicts, not counts. Requires:
  (a) every generated completion key present in verified_rows.jsonl
  (b) zero exception / replay_failed verdicts among them
Anything else and pool_analyze's complete-theorem rule would silently shrink n.
"""
import json, sys, collections
sys.path.insert(0, "/workspace/SmolBench"); sys.path.insert(0, "/workspace/SmolBench/scripts")
from smolbench.deduction.lean import runner

D = "/workspace/SmolBench/notebooks/deduction/results/runs/flip2_nemotron-3-nano-4b/"
R6 = "/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/"

def key(r):
    return runner._row_key(r.get("model",""), r.get("theorem_id",""), int(r.get("k",-1)),
                           r.get("rung",""), int(r.get("replicate_idx",-1)))

want = set(runner.load_cell_whitelist(R6 + "whitelist_missing.json"))
gen = {key(json.loads(l)) for l in open(D + "all_rows.jsonl")
       if l.strip() and json.loads(l).get("kind") == "cell"}
gen_new = want & gen

ver = {}
for l in open(D + "verified_rows.jsonl"):
    if not l.strip():
        continue
    r = json.loads(l)
    if r.get("kind") == "cell":
        ver.setdefault(key(r), r)          # earliest-wins, the study loader's rule

absent = sorted(gen_new - set(ver))
counts = collections.Counter(ver[k].get("verdict") for k in gen_new if k in ver)
bad = counts.get("exception", 0) + counts.get("replay_failed", 0)
out = {
    "n_whitelist_missing": len(want),
    "n_generated": len(gen_new),
    "n_not_generated": len(want - gen),
    "n_verified": len(gen_new) - len(absent),
    "generated_but_unverified": absent[:20],
    "verdict_counts": dict(counts),
    "exception_plus_replay_failed": bad,
    "PASS": len(absent) == 0 and bad == 0 and len(gen_new) > 0,
}
open(R6 + "content_gate_post.json", "w").write(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
if not out["PASS"]:
    raise SystemExit("CONTENT GATE FAILED -- do NOT pool; verdicts degenerated or rows missing")
print("CONTENT GATE PASSED")
