#!/bin/bash
# exits when the r6 generate driver is gone (natural finish, SIGINT cut, or crash)
while pgrep -f "r6_driver.py generate" >/dev/null; do sleep 20; done
echo "GENERATE PROCESS GONE $(date -u)"
