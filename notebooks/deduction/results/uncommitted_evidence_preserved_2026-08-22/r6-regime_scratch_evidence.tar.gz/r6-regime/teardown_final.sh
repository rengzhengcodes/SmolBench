#!/bin/bash
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/env.sh
echo "=== terminate by OUR tag only (flip2-nemotron-3-nano-4b) ==="
for r in us-west-2 us-east-1 us-east-2; do
  ids=$(aws ec2 describe-instances --region $r \
    --filters "Name=instance-state-name,Values=pending,running,stopping,stopped" \
              "Name=tag:Experiment,Values=flip2-nemotron-3-nano-4b" \
    --query "Reservations[].Instances[].InstanceId" --output text)
  echo "$r tagged: [$ids]"
  [ -n "$ids" ] && aws ec2 terminate-instances --region $r --instance-ids $ids --output text
done
echo; echo "=== FULL describe: ALL non-terminated instances, all 3 regions ==="
for r in us-west-2 us-east-1 us-east-2; do
  echo "--- $r ---"
  aws ec2 describe-instances --region $r \
    --filters "Name=instance-state-name,Values=pending,running,stopping,stopped" \
    --query "Reservations[].Instances[].[InstanceId,InstanceType,State.Name,Tags[?Key=='Experiment']|[0].Value,LaunchTime]" \
    --output text
done
echo "=== explicit state of box 4 ==="
aws ec2 describe-instances --region us-east-1 --instance-ids i-0e9b39efb4cdd6c8b \
  --query 'Reservations[].Instances[].[InstanceId,State.Name]' --output text
date -u
