set -a
. /workspace/SmolBench/notebooks/deduction/keys.env
. /workspace/SmolBench/notebooks/ec2-operator.env
set +a
# IDENTICAL to r5/env.sh: legs 1+2 were both verified TODAY with the GitHub
# token UNSET (anonymous LeanDojo). keys.env now carries a LIVE token, but
# changing the verifier's auth mode mid-draw would be a config change inside
# the very experiment that measures config-invariance. Kept unset; the drift
# gate re-proves the verifier against leg-2's own stored verdicts.
unset GITHUB_ACCESS_TOKEN
export R5_DIR=/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime
export R6_DIR=/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime
# The 2026-08-21 ops incident: LeanDojo shells out to `lake`, which lives here.
export PATH="$HOME/.elan/bin:$PATH"
