"""Merge the 88 graded completion cells into the run dir's verified_rows.jsonl.

87 graded cleanly. ONE did not, and is merged AS an `exception` row on purpose:

  CategoryTheory.Limits.Types.colimit_sound k=0 stepk:1 -> DojoCrashError:
  Unexpected EOF, DETERMINISTICALLY (2 of 2 isolated attempts, workers=1).
  The theorem's own ground-truth sanity replay succeeds (1/1 tactics), so
  neither the corpus nor the theorem is at fault; the rerun's candidate is a
  110,920-character runaway generation that kills the Dojo subprocess.

Merging the exception row rather than dropping it silently is the honest
option AND the one the committed estimator already handles: `load_leg` treats a
rerun `exception` as "infrastructure, not a measurement", moves the cell to
`missing`, and the complete-theorem rule then drops that theorem. That theorem
has exactly ONE whitelisted cell, so the cost is 1 pair: leg 2 = 199, pooled =
399. No estimator code changes; the same rule produced the committed n=311.

Hard ceiling: abort if exceptions exceed 5% of the completion cells, which
would be the degenerate-verifier signature rather than one runaway candidate.
"""
import json, sys, pathlib, collections
sys.path.insert(0, "/workspace/SmolBench"); sys.path.insert(0, "/workspace/SmolBench/scripts")
import flip_probe as fp
from smolbench.deduction.lean import runner

R6 = pathlib.Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime")
D = pathlib.Path("/workspace/SmolBench/notebooks/deduction/results/runs/flip2_nemotron-3-nano-4b")

def key(r):
    return runner._row_key(r.get("model", ""), r.get("theorem_id", ""), int(r.get("k", -1)),
                           r.get("rung", ""), int(r.get("replicate_idx", -1)))

want = set(runner.load_cell_whitelist(str(R6 / "whitelist_missing.json")))
out = [json.loads(l) for l in (R6 / "rerun_new" / "new_verified_rows.jsonl").read_text().splitlines() if l.strip()]
cells = {key(r): r for r in out if r.get("kind") == "cell"}
assert set(cells) == want, "verified scratch does not cover exactly the 88 completion cells"

counts = collections.Counter(r.get("verdict") for r in cells.values())
bad = sorted(k for k, r in cells.items() if r.get("verdict") in ("exception", "replay_failed", "unverified"))
print("verdicts:", dict(counts), "| not-clean:", len(bad))
if len(bad) / len(cells) > 0.05:
    raise SystemExit("ABORT: >5% of completion cells failed to grade -- degenerate verifier, not a runaway candidate")

ver = [json.loads(l) for l in (D / "verified_rows.jsonl").read_text().splitlines() if l.strip()]
already = {key(r) for r in ver if r.get("kind") == "cell"}
if want & already:
    raise SystemExit("completion cells already merged -- refusing to append twice")
(R6 / "verified_rows_before_merge.jsonl").write_bytes((D / "verified_rows.jsonl").read_bytes())

with open(D / "verified_rows.jsonl", "a") as f:
    for k in sorted(want):
        f.write(json.dumps(cells[k], ensure_ascii=False) + "\n")

after = [json.loads(l) for l in (D / "verified_rows.jsonl").read_text().splitlines() if l.strip()]
ac = [r for r in after if r.get("kind") == "cell"]
res = {
    "n_merged": len(want), "verdict_counts": dict(counts),
    "not_clean": [list(k) for k in bad],
    "not_clean_reason": "DojoCrashError: Unexpected EOF, deterministic (2/2), 110920-char runaway candidate; theorem sanity replay = success 1/1",
    "n_cells_after_merge": len(ac), "n_distinct_after_merge": len({key(r) for r in ac}),
    "expected_leg2_pairs": 200 - len(bad),
}
(R6 / "merge_result.json").write_text(json.dumps(res, indent=2) + "\n")
print(json.dumps(res, indent=2))
