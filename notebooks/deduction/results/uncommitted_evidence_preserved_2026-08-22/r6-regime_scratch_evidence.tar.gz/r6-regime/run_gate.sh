#!/bin/bash
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/env.sh
cd /workspace/SmolBench
exec .venv-lean/bin/python $R6_DIR/r6_driver.py gate --workers 3 --n 88
