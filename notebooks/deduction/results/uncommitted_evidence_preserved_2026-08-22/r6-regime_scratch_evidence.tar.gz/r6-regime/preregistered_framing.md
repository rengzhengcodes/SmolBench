# Verdict framing, fixed BEFORE the box-4 cells were graded

Written 2026-08-21 21:45 UTC, while the sweep was still generating and no new
verdict existed. Purpose: stop a p-value that lands near 0.05 from being
promoted after the fact.

Projected from the committed n=311 numbers (shift 3.215 pt, cluster SE 1.810 pt),
assuming the box-4 cells behave like the 311 already drawn:

* pooled cluster SE at n=400 falls to roughly 1.81 * sqrt(311/400) ~= 1.60 pt
* 95% cluster CI ~= [0.08, 6.35] pt — its lower edge sits ON zero
* McNemar exact p lands somewhere near 0.05, either side
* MDE80 ~= 2.802 * 1.60 ~= 4.5 pt, still ABOVE the 3.2 pt point estimate

The decision rule, fixed now:

1. **"Survives"** iff the pooled point estimate stays inside roughly [2, 4.5] pt
   and the flip rate stays inside the committed [0.061, 0.127] CI. This is a
   statement about the ESTIMATE reproducing, not about significance.
2. **"Reaches significance"** is reported as a bare fact (p < 0.05 or not) and is
   NOT upgraded to "confirmed" at any p. With MDE80 above the point estimate,
   n=400 is underpowered for its own effect size, so a p of 0.048 and a p of
   0.062 carry the same evidential weight here and must be described the same way.
3. **"Dissolves"** iff the point estimate moves below ~1.5 pt or the sign flips.
4. Whatever happens, the headline sentence names the power: the draw bounds the
   process term, it does not establish it.
5. The per-process homogeneity test is the falsifier that matters most. If box 4
   (a fresh L40S, same AZ and type as box 3) shows a shift far from the other
   three strata, the "persistent rerun-higher" reading is process-specific rather
   than a property of the rerun leg, and that supersedes the pooled p.
