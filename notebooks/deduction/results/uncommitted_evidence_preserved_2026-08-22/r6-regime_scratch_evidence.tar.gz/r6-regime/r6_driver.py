"""regime-completion: regenerate EXACTLY the 88 leg-2 cells the 2026-08-21
sweep did not produce (spot reclaims), under the IDENTICAL pinned stock
reconstruction, and re-pool over the full 400-cell draw.

Differences from r5_driver.py (the leg-2 driver this is a continuation of):

* ``_whitelist_path`` is patched to R6/whitelist_missing.json -- the 88-cell
  SUBSET.  The run dir's own whitelist.json stays the full 200 because
  pool_analyze.py reads it as the leg's denominator.  Narrowing the generate
  whitelist also narrows ``_select_theorems`` from 131 theorems to 65, so the
  sweep does not re-pay 66 ground-truth sanity replays for cells that are
  already on disk.
* No ``setup``: the run dir, its whitelist, its manifest and its 112 finished
  cell rows are already there and MUST NOT be disturbed.  ``runner.sweep``'s
  own resume rule (skip any key already in all_rows.jsonl) is the second,
  independent guard that the 112 are never regenerated.
* ``gate`` replaces r5's ``legb``: leg 2 already re-verified all 200 originals
  today, so the pre-spend check is a DRIFT gate on a sample of those
  already-verified originals -- re-verify them a second time in a scratch dir
  the run dir does not contain, and require today's verdicts to reproduce.
"""
from __future__ import annotations

import argparse
import collections
import json
import logging
import os
import random
import sys
from pathlib import Path

REPO = Path("/workspace/SmolBench")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

R6 = Path(os.environ.get("R6_DIR", str(Path(__file__).resolve().parent)))

import flip_probe as fp  # noqa: E402
from smolbench.deduction.lean import runner  # noqa: E402

# --- identical run identity to leg 2 (advisor gate: the S3 dest prefix is
# derived from FLIP_RUN_NAME) -------------------------------------------------
fp.FLIP_RUN_NAME = "flip2_nemotron-3-nano-4b"
fp.EC2_TAG = "flip2-nemotron-3-nano-4b"
fp.EC2_STATE_FILE_NAME = ".ec2_state_flip2_nemotron-3-nano-4b.json"
fp.N_SAMPLE = 200
fp.EC2_INSTANCE_TYPE = os.environ.get("R6_TYPES", "g6e.2xlarge,g6e.4xlarge")

MISSING_WHITELIST = R6 / "whitelist_missing.json"
_FULL_WHITELIST = fp._whitelist_path  # the run dir's 200-cell file


def _missing_whitelist_path() -> Path:
    return MISSING_WHITELIST


fp._whitelist_path = _missing_whitelist_path


def _assert_run_dir_intact() -> None:
    """Refuse to do anything if the 112 finished cells are not where we left them."""
    run_dir = fp._flip_run_dir()
    full = sorted(runner.load_cell_whitelist(str(run_dir / "whitelist.json")))
    if len(full) != 200:
        raise SystemExit(f"run-dir whitelist.json has {len(full)} cells, expected 200")
    rows = [json.loads(l) for l in (run_dir / "all_rows.jsonl").read_text().splitlines() if l.strip()]
    keys = {
        runner._row_key(r.get("model", ""), r.get("theorem_id", ""), int(r.get("k", -1)),
                        r.get("rung", ""), int(r.get("replicate_idx", -1)))
        for r in rows if r.get("kind") == "cell"
    }
    want = sorted(runner.load_cell_whitelist(str(MISSING_WHITELIST)))
    if len(want) != 88:
        raise SystemExit(f"missing whitelist has {len(want)} cells, expected 88")
    if set(want) & keys:
        raise SystemExit("missing whitelist overlaps cells already on disk -- STOP")
    if set(want) | keys != set(full):
        raise SystemExit("missing whitelist + on-disk cells != the 200-cell leg-2 whitelist")
    logging.info("run dir intact: %d done + %d to generate = 200", len(keys), len(want))


# ---------------------------------------------------------------------------
# PRE-SPEND DRIFT GATE
# ---------------------------------------------------------------------------
def _gate(args: argparse.Namespace) -> None:
    lvr = fp._load_lean_verify_rows()
    lvr.require_py312()
    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        lvr.check_workers(args.workers, meminfo.read_text())
    _assert_run_dir_intact()

    src = fp._originals_dir() / lvr.VERIFIED_FILENAME
    stored = fp.dedupe_rows_earliest_wins(
        [json.loads(l) for l in src.read_text().splitlines() if l.strip()]
    )
    missing = sorted(runner.load_cell_whitelist(str(MISSING_WHITELIST)))
    pool = [k for k in missing if k in stored]
    if len(pool) != len(missing):
        raise SystemExit(f"only {len(pool)}/{len(missing)} originals present in {src}")
    rng = random.Random(20260821)
    sample = sorted(rng.sample(pool, min(args.n, len(pool))))

    # Scratch dir OUTSIDE the run dir: verify_run writes verified_rows.jsonl
    # next to its rows file, and the run dir's copy is the pooled analysis's
    # ORIGINALS side. It must not be touched.
    gate_dir = R6 / "gate_originals"
    gate_dir.mkdir(parents=True, exist_ok=True)
    rows_path = gate_dir / "originals_all_rows.jsonl"
    fresh = []
    for k in sample:
        r = dict(stored[k])
        r["_today_verdict"] = r.get("verdict")          # leg-2's 2026-08-21 verdict
        r["_today_lean_error"] = r.get("lean_error")
        r["verdict"] = "unverified"
        r["lean_error"] = None
        r["final_state_pp"] = None
        fresh.append(r)
    new_bytes = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in fresh).encode()
    scratch_rows = gate_dir / "_scratch" / lvr.ROWS_FILENAME
    no_resume = scratch_rows.exists() and scratch_rows.read_bytes() != new_bytes
    rows_path.write_bytes(new_bytes)
    verified_path = gate_dir / lvr.VERIFIED_FILENAME

    client = fp._LocalRunClient(
        rows_path=rows_path, verified_path=verified_path,
        rows_filename=lvr.ROWS_FILENAME, verified_filename=lvr.VERIFIED_FILENAME,
    )
    with lvr._dojo_cache_lock():
        rc = lvr.verify_run(
            client=client, bucket="local-drift-gate", key_prefix="",
            run="_scratch", workers=args.workers, workdir=gate_dir, no_resume=no_resume,
        )
    if rc != 0:
        raise SystemExit(f"gate: verify_run rc={rc}")

    out_rows = fp.dedupe_rows_earliest_wins(
        [json.loads(l) for l in verified_path.read_text().splitlines() if l.strip()]
    )
    vs_today = {k: (r.get("_today_verdict", ""), r.get("verdict", "")) for k, r in out_rows.items()}
    vs_study = {k: (r.get("_study_verdict", ""), r.get("verdict", "")) for k, r in out_rows.items()}
    d_today, d_study = fp.verifier_drift_stats(vs_today), fp.verifier_drift_stats(vs_study)
    counts = collections.Counter(v for _, v in vs_today.values())
    out = {
        "sampled_from": "the 88 leg-2 cells this run regenerates (their ORIGINALS side)",
        "n": d_today["n"],
        "vs_leg2_2026-08-21_verdicts": {
            "agree": d_today["agree"], "agreement_rate": d_today["agreement_rate"],
            "disagreements": d_today["disagreements"][:20],
        },
        "vs_study_verdicts": {
            "agree": d_study["agree"], "agreement_rate": d_study["agreement_rate"],
            "disagreements": d_study["disagreements"][:20],
        },
        "reverified_verdict_counts": dict(counts),
        "github_token": "UNSET (anonymous LeanDojo), identical to legs 1 and 2",
    }
    (R6 / "drift_gate_pre.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))
    exc = counts.get("exception", 0)
    rf = counts.get("replay_failed", 0)
    print(f"\nDRIFT GATE: {d_today['agree']}/{d_today['n']} reproduce leg-2's verdicts; "
          f"exception={exc} replay_failed={rf}")
    if d_today["n"] == 0:
        raise SystemExit("DRIFT GATE FAILED: nothing verified.")
    if (exc + rf) / d_today["n"] > 0.25:
        raise SystemExit(
            "DRIFT GATE FAILED: verdicts degenerated to exception/replay_failed "
            "(the dead-token / missing-elan-PATH signature). STOP -- do not provision."
        )
    if d_today["agreement_rate"] < 0.95:
        raise SystemExit(
            f"DRIFT GATE FAILED: only {d_today['agreement_rate']:.3f} of today's "
            "verdicts reproduce. The verifier is not the one that graded leg 2."
        )
    print("DRIFT GATE PASSED -- safe to provision.")


def _generate(args: argparse.Namespace) -> None:
    _assert_run_dir_intact()
    fp._stage_generate(argparse.Namespace(regions=args.regions))


def _lega(args: argparse.Namespace) -> None:
    lvr = fp._load_lean_verify_rows()
    lvr.require_py312()
    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        lvr.check_workers(args.workers, meminfo.read_text())
    from smolbench.evals import _aws

    real_client = _aws.fresh_client("s3", lvr.S3_REGION)
    with lvr._dojo_cache_lock():
        rc = lvr.verify_run(
            client=real_client, bucket=fp.SPOOL_BUCKET, key_prefix=fp.SPOOL_PREFIX,
            run=fp.FLIP_RUN_NAME, workers=args.workers,
            workdir=fp._flip_run_dir().parent,
        )
    if rc != 0:
        raise SystemExit(f"lega: verify_run rc={rc}")
    print("lega: done ->", fp._flip_run_dir() / fp.VERIFIED_FILENAME)


def _analyze(args: argparse.Namespace) -> None:
    """flip_probe's own analyze. Restore the FULL 200-cell whitelist for it --
    the 88-cell subset is a GENERATION scope, not the leg's denominator."""
    fp._whitelist_path = _FULL_WHITELIST
    try:
        fp._stage_analyze(argparse.Namespace())
    finally:
        fp._whitelist_path = _missing_whitelist_path


def _spool(args: argparse.Namespace) -> None:
    n = fp._spool_flip_run(fp._flip_run_dir())
    print(f"spooled {n} file(s) to s3://{fp.SPOOL_BUCKET}/{fp.SPOOL_PREFIX}/{fp.FLIP_RUN_NAME}/")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["check", "gate", "generate", "lega", "spool", "analyze"])
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--n", type=int, default=45, help="gate sample size")
    ap.add_argument("--regions", default="us-west-2,us-east-1,us-east-2")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    {"check": lambda a: _assert_run_dir_intact(), "gate": _gate, "generate": _generate,
     "lega": _lega, "spool": _spool, "analyze": _analyze}[args.cmd](args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
