"""Render REPORT.md from the finished r6 artifacts. No number below is typed by
hand: all are read from the JSON the estimator wrote, so the prose cannot drift."""
import json, pathlib, hashlib

R6 = pathlib.Path("/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime")
R5 = R6.parent / "r5-regime"
J = lambda p: json.loads((R6 / p).read_text())

rep, byp = J("regime_mean_report_full.json"), J("by_process_full.json")
gate_pre, merge, legchk = J("drift_gate_pre.json"), J("merge_result.json"), J("leg_check.json")
spend = J("spend.json")
old = json.loads((R5 / "regime_mean_report.json").read_text())

P, Pold = rep["pooled"]["flip"], old["pooled"]["flip"]
L1, L2 = rep["legs"]["leg1_2026-08-18"]["flip"], rep["legs"]["leg2_2026-08-21"]["flip"]
L2old = old["legs"]["leg2_2026-08-21"]["flip"]
het, hom = rep["leg_heterogeneity"], byp["_homogeneity"]
sha = hashlib.sha256((R6 / "pool_analyze.py").read_bytes()).hexdigest()
f2, f3 = (lambda x: f"{x:.2f}"), (lambda x: f"{x:.3f}")
ci = lambda v: f"[{v[0]:.2f}, {v[1]:.2f}]"
ci3 = lambda v: f"[{v[0]:.3f}, {v[1]:.3f}]"

shift, fr = P["mean_shift_pts"], P["flip_rate"]
frci = Pold["flip_rate_cp_ci95"]
in_win, in_fr = 2.0 <= shift <= 4.5, frci[0] <= fr <= frci[1]
sig = P["mcnemar_exact_p"] < 0.05
box4 = byp["leg2c_box4_20260821_completion"]

rows = []
for name, v in byp.items():
    if name == "_homogeneity":
        continue
    rows.append(f"| `{name}` | {v['n']} | {v['b_orig_pass_rerun_fail']}/{v['c_orig_fail_rerun_pass']} "
                f"| {f3(v['flip_rate'])} | **{f2(v['mean_shift_pts'])}** | {ci(v['mean_shift_ci95_cluster_boot_pts'])} |")

md = f"""# regime-completion — the section-7.2 regime-mean draw, finished

## Verdict

**By the preregistered rule the rerun-higher shift SURVIVES — at the bottom edge of
the window — and it does NOT reach significance (McNemar exact p = {f3(P['mcnemar_exact_p'])}).**

The decision rule was fixed *before* these cells were graded
(`preregistered_framing.md`, 21:45Z). Rule 1's test is that the pooled estimate sits in
[2.0, 4.5] pt and the flip rate inside the committed CI: the estimate is
**+{f2(shift)} pt** and the flip rate **{f3(fr)}** in {ci3(frci)}, so both hold. Rule 3's
"dissolves" test (below ~1.5 pt, or a sign flip) does not fire. The scored answer is
therefore *survives*, and it is recorded as such rather than re-scored after the fact.

State the boundary plainly, though: **{f2(shift)} pt sits {f2(shift-2.0)} pt above a 2.0 pt
floor**, so the classification would flip on a single discordant cell. And two caveats
carry more weight than the label:

1. **The effect roughly halved.** +{f2(Pold['mean_shift_pts'])} pt on the committed n={Pold['n']}
   became +{f2(shift)} pt on n={P['n']}. The added cells moved the estimate DOWN, not toward
   significance. `preregistered_framing.md` projected the CI lower edge landing on zero and
   p near 0.05 *assuming the new cells behaved like the 311 already drawn*. They did not:
   leg 2 went from +{f2(L2old['mean_shift_pts'])} pt on 111 cells to +{f2(L2['mean_shift_pts'])} pt on {L2['n']}.
2. **The one process drawn fresh for this package reversed sign.** Box 4 — {box4['n']} cells,
   the largest leg-2 stratum — came back at **{f2(box4['mean_shift_pts'])} pt**, the only
   negative stratum of the four. The four are not statistically heterogeneous
   (Q = {f2(hom['Q'])}, df = {hom['df']}, p = {f3(hom['p'])}), but that test cannot resolve a 2-pt
   effect against per-stratum SEs of 3.2–4.3 pt, so "homogeneous" means "undetectably
   different", not "agreeing".

**What this draw establishes: a BOUND, not an effect.** MDE80 (cluster) is
{f2(P['mde80_cluster_pts'])} pt against a point estimate of {f2(shift)} pt — n={P['n']} is underpowered
for its own effect size. Per rule 2, a p just under and just over 0.05 would carry identical
weight here; at p = {f3(P['mcnemar_exact_p'])} the question does not arise. Cross-process pass@1
variation is bounded by roughly ±5 pt; a persistent rerun-higher shift is not established.

## Headline (pooled, n = {P['n']} cells over {P['n_theorems']} theorems)

| quantity | value |
|---|---|
| a / b / c / d | {P['a_both_pass']} / {P['b_orig_pass_rerun_fail']} / {P['c_orig_fail_rerun_pass']} / {P['d_both_fail']} |
| pass@1 study → rerun | {f3(P['pass1_orig'])} → {f3(P['pass1_rerun'])} |
| **flip rate** (b+c)/n | **{f3(P['flip_rate'])}** — Clopper-Pearson {ci3(P['flip_rate_cp_ci95'])}, cluster-boot {ci3(P['flip_rate_ci95_cluster_boot'])} |
| **mean shift** (c−b)/n | **+{f2(P['mean_shift_pts'])} pt** |
| **cluster-boot 95% CI** | **{ci(P['mean_shift_ci95_cluster_boot_pts'])} pt** (boot SE {f2(P['mean_shift_boot_se_pts'])} pt) |
| naive 95% CI | {ci(P['mean_shift_ci95_naive_pts'])} pt (SE {f2(P['mean_shift_se_naive_pts'])} pt) |
| **McNemar exact p** | **{f3(P['mcnemar_exact_p'])}** |
| design effect (cluster/naive) | {f2(P['deff_cluster_vs_naive'])} |
| **MDE80 (cluster)** | **{f2(P['mde80_cluster_pts'])} pt** (naive {f2(P['mde80_naive_pts'])} pt) |

## Movement from the committed draw

| | committed n={Pold['n']} | full n={P['n']} |
|---|---|---|
| mean shift | +{f2(Pold['mean_shift_pts'])} pt | **+{f2(P['mean_shift_pts'])} pt** |
| cluster CI | {ci(Pold['mean_shift_ci95_cluster_boot_pts'])} | {ci(P['mean_shift_ci95_cluster_boot_pts'])} |
| flip rate | {f3(Pold['flip_rate'])} | {f3(P['flip_rate'])} |
| McNemar p | {f3(Pold['mcnemar_exact_p'])} | {f3(P['mcnemar_exact_p'])} |
| MDE80 cluster | {f2(Pold['mde80_cluster_pts'])} pt | {f2(P['mde80_cluster_pts'])} pt |

The added cells moved the estimate DOWN, not toward significance. The projection in
`preregistered_framing.md` (CI lower edge landing on zero, p near 0.05) assumed the
new cells would behave like the 311 already drawn. They did not: leg 2 went from
+{f2(L2old['mean_shift_pts'])} pt on 111 cells to **+{f2(L2['mean_shift_pts'])} pt on {L2['n']}**.

## Per-leg and leg heterogeneity

| leg | n | theorems | b/c | flip | shift (pt) | cluster CI | McNemar p |
|---|---|---|---|---|---|---|---|
| leg 1 (2026-08-18) | {L1['n']} | {L1['n_theorems']} | {L1['b_orig_pass_rerun_fail']}/{L1['c_orig_fail_rerun_pass']} | {f3(L1['flip_rate'])} | +{f2(L1['mean_shift_pts'])} | {ci(L1['mean_shift_ci95_cluster_boot_pts'])} | {f3(L1['mcnemar_exact_p'])} |
| leg 2 (2026-08-21) | {L2['n']} | {L2['n_theorems']} | {L2['b_orig_pass_rerun_fail']}/{L2['c_orig_fail_rerun_pass']} | {f3(L2['flip_rate'])} | +{f2(L2['mean_shift_pts'])} | {ci(L2['mean_shift_ci95_cluster_boot_pts'])} | {f3(L2['mcnemar_exact_p'])} |

Leg heterogeneity: diff {f2(het['shift_diff_pts'])} pt, SE {f2(het['se_pts'])} pt, **z = {f2(het['z'])}**.
The legs remain formally consistent, but the gap widened from
{f2(old['leg_heterogeneity']['shift_diff_pts'])} pt (z = {f2(old['leg_heterogeneity']['z'])}) as leg 2 filled in.

## Per-process split — preregistration rule 5

| stratum | n | b/c | flip | shift (pt) | cluster CI |
|---|---|---|---|---|---|
{chr(10).join(rows)}

Homogeneity across {hom['k_processes']} serving processes: **Q = {f2(hom['Q'])}, df = {hom['df']}, p = {f3(hom['p'])}**;
inverse-variance weighted mean {f2(hom['weighted_mean_shift_pts'])} pt.

The four strata run {f2(byp['leg1_box0_20260818_g6e2xl_usw2a']['mean_shift_pts'])} /
{f2(byp['leg2a_box1_2_20260821_g6e4xl_use2']['mean_shift_pts'])} /
{f2(byp['leg2b_box3_20260821_g6e2xl_use1d']['mean_shift_pts'])} /
{f2(box4['mean_shift_pts'])} pt. Box 3 and box 4 are the SAME instance type in the SAME
AZ (g6e.2xlarge, us-east-1d) on the same day under the same pinned reconstruction,
and they differ by {f2(byp['leg2b_box3_20260821_g6e2xl_use1d']['mean_shift_pts'] - box4['mean_shift_pts'])} pt
with opposite signs. That is the cleanest statement the draw supports: **the sign of the
rerun-vs-study shift is not stable across serving processes.**

Read that claim at its true resolution, though: it rests on **single-digit discordant
counts per stratum**. Box 4's {f2(box4['mean_shift_pts'])} pt is b={box4['b_orig_pass_rerun_fail']}, c={box4['c_orig_fail_rerun_pass']} — {box4['b_orig_pass_rerun_fail']+box4['c_orig_fail_rerun_pass']} discordant cells out of {box4['n']};
box 3's +{f2(byp['leg2b_box3_20260821_g6e2xl_use1d']['mean_shift_pts'])} pt is b={byp['leg2b_box3_20260821_g6e2xl_use1d']['b_orig_pass_rerun_fail']}, c={byp['leg2b_box3_20260821_g6e2xl_use1d']['c_orig_fail_rerun_pass']} — {byp['leg2b_box3_20260821_g6e2xl_use1d']['b_orig_pass_rerun_fail']+byp['leg2b_box3_20260821_g6e2xl_use1d']['c_orig_fail_rerun_pass']} out of {byp['leg2b_box3_20260821_g6e2xl_use1d']['n']}. Every
per-stratum McNemar p is ≥ {f2(min(v['mcnemar_exact_p'] for k,v in byp.items() if k!='_homogeneity'))}. The instability is real in the sense that no
stratum reproduces the pooled estimate, but no single stratum on its own excludes zero.

## What was regenerated

* The committed draw stood at n={Pold['n']} because three spot reclaims cut the leg-2
  sweep at 112 of its 200 whitelisted cells; the COMPLETE-THEOREM rule (a theorem with
  any missing whitelisted cell contributes nothing, so a truncated sweep cannot bias the
  rung mix) left only {L2old['n']} analyzable pairs.
* This package regenerated **exactly the {merge['n_merged']} missing cells** (65 theorems) on
  box 4 under the identical pinned stock reconstruction, then verified and merged them.
* Target was 400 analyzable; **actual is {P['n']}** = leg 1 {legchk['leg1']['n_pairs']} + leg 2 {legchk['leg2']['n_pairs']}.
  The single missing pair is `CategoryTheory.Limits.Types.colimit_sound k=0 stepk:1`,
  whose rerun candidate is a **110,920-character runaway generation that crashes the Lean
  Dojo subprocess deterministically** (`DojoCrashError: Unexpected EOF`, 2 of 2 isolated
  attempts at workers=1; the theorem's own ground-truth sanity replay succeeds 1/1).
  `load_leg` classes a rerun `exception` as infrastructure rather than a measurement and
  drops the theorem — the same rule that produced the committed n=311, applied unchanged.
  That theorem has exactly one whitelisted cell, so the cost is one pair.

## Two defects found and fixed in the verification tail

`verify_run` could not be used against the run dir for a SECOND generation pass:

1. **Index misalignment (loud).** It seeds `out_rows` from the prior
   `verified_rows.jsonl` (243 rows) but computes `pending` indices against the new
   `all_rows.jsonl` (331 rows), so `fan_out_verdict` raised `IndexError` on the appended
   cells. Its invariant ("a prior upload never reorders or removes anything") holds only
   while `all_rows.jsonl` is frozen after a verification pass. Audited: the first 243
   positions ARE aligned (0 mismatches) and the run crashed before its first checkpoint
   upload, so `verified_rows.jsonl` stayed byte-identical to `backup_pre_r6`
   (sha `12e06467…`). Nothing was corrupted.
2. **Resume-by-group would have silently skipped a cell (quiet — the dangerous one).**
   `resume_done_groups` marks a whole `(theorem_id, k)` group done if ANY of its cells has
   a verdict. Exactly one new cell — `Prod.swap_iInf k=0 hint:2` — shares a group leg 2
   already finished, which is why the crashed run reported 87 pending rows for 88 new
   cells. It would have stayed `unverified` forever and its theorem would have been
   dropped with no error raised.

Fix: verify the 88 in isolation via `_LocalRunClient` in a scratch dir with
`no_resume=True` (the pattern the pre-spend drift gate already proved on this machine
today), then merge explicitly. Same verifier, same env, same workers — the verdicts come
from the verifier that graded legs 1 and 2.

## Gates

* **Pre-spend drift gate (banked, not redone):** {gate_pre['n']}/{gate_pre['n']} of the 88 originals'
  verdicts reproduced against BOTH leg-2's same-day verdicts and the study verdicts
  (agreement 1.000, zero disagreements). `GITHUB_ACCESS_TOKEN` UNSET (anonymous LeanDojo),
  identical to legs 1 and 2.
* **Content gate on the rerun side (folded into the merge):** {merge['n_merged']}/{merge['n_merged']} completion
  cells graded, verdicts {merge['verdict_counts']}; exception+replay_failed = {len(merge['not_clean'])},
  under the 5% abort ceiling. This reads VERDICTS, not row counts — counts alone once
  certified a lane that had lost 93.8% of its cells.
* **Leg-completeness gate (run before pooling):** leg 1 {legchk['leg1']['n_pairs']}/200 with
  {legchk['leg1']['n_theorems_dropped']} theorems dropped; leg 2 {legchk['leg2']['n_pairs']}/200 with
  {legchk['leg2']['n_theorems_dropped']} dropped, and the one drop is the audited Dojo-crash cell.
* **Verifier drift, pooled:** {rep['pooled']['verifier_drift']['agree']}/{rep['pooled']['verifier_drift']['n']} agree (rate {f3(rep['pooled']['verifier_drift']['agreement_rate'])}).
* **Transport-fault guard:** empty rerun candidate proofs with prompt_tokens>0 = {legchk['leg2']['empty_rerun_candidate_proof']['prompt_tokens_gt_0']} (both legs).

## Identity of the reconstruction

build dev122, image `vllm/vllm-openai@sha256:26354b5e…`, weights digest `95c2fc6e…`,
hf_revision `dfaf35de`, tp=1, seed 0, temp 0.7, max_tokens 32768, stock args incl.
`--enable-prefix-caching`. Box 3 vs box 4 `server_config` differ ONLY in instance id, GPU
UUID and timestamp (`server_config_box3_vs_box4_diff.json`). Estimator byte-identical to
the committed run: `sha256(pool_analyze.py) = {sha[:16]}…`, equal in r5 and r6.

## Spend and teardown

```json
{json.dumps(spend, indent=2)}
```

Box `i-0e9b39efb4cdd6c8b` (g6e.2xlarge, us-east-1d) was terminated by the driver's own
`finally: ec2.shutdown_instance()` at 23:26:22Z — before the verification tail, which is
local CPU only and needed no GPU. Verified terminated across us-east-1 / us-east-2 /
us-west-2: **zero instances tagged `smolbench:experiment=flip2-nemotron-3-nano-4b` in any
region**, and box 4 explicitly `terminated` by instance id (`teardown_final.txt`).

Two teardown notes worth carrying forward:

* `teardown_r6.sh` / `teardown_final.sh` filtered on tag key **`Experiment`**, but the real
  key this repo writes is **`smolbench:experiment`**. That filter matched nothing and its
  terminate step was a silent no-op. It did not cost anything here — the driver terminated
  its own box and the explicit instance-id check is what actually confirms teardown — but a
  run that relied on the tag sweep to catch a leaked box would have been told "clean" while
  the box billed. Fix the key before reusing those scripts.
* One foreign instance is running and is **NOT this package's**:
  `i-047406b97c0d2a80f`, p5.48xlarge spot, us-west-2b, launched 23:48:39Z, tagged
  `smolbench:experiment=moetp8` — the concurrent MoE-tp8 workflow. It was deliberately left
  alone. (Also present: `i-0e52cb0bb33999a94`, m7i.16xlarge, **stopped** since 2026-08-16,
  tagged `verify-lean`.) Flagging it because a p5.48xlarge is the most expensive box in this
  account's rotation and it should be confirmed as intentionally owned by that workflow.
"""
(R6 / "REPORT.md").write_text(md)
print(md[:1800])
