#!/bin/bash
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r6-regime/env.sh
cd /workspace/SmolBench
exec .venv/bin/python $R6_DIR/r6_driver.py generate --regions us-west-2,us-east-1,us-east-2
