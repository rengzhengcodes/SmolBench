#!/bin/bash
# Graceful cut of the generation sweep.
# SIGINT (not SIGTERM): CPython raises KeyboardInterrupt, so _stage_generate's
# `finally: ec2.shutdown_instance()` RUNS. SIGTERM would skip it and leak the box.
set -x
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime/env.sh
pkill -INT -f "r5_driver.py generate"
sleep 90
pgrep -af "r5_driver.py generate" || echo "generate process gone"
tail -20 $R5_DIR/generate.log
# Belt and braces: terminate the box explicitly if it survived.
aws ec2 describe-instances --region us-east-2 \
  --filters "Name=instance-state-name,Values=pending,running" \
  --query "Reservations[].Instances[].[InstanceId,InstanceType,State.Name,Tags[?Key=='Experiment']|[0].Value]" --output text
