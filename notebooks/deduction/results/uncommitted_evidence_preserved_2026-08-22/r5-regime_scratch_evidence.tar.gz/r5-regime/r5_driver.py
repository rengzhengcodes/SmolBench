"""regime-mean (leg 2): driver around scripts/flip_probe.py for the DISJOINT
200-cell extension of the section-6.2 flip sample.

Subcommands
-----------
setup    copy the extension whitelist/manifest into the flip2 run dir under the
         filenames flip_probe expects.
legb     PRE-SPEND GATE. Re-verify the STUDY's original candidates for the new
         whitelist, locally only (never touches S3 for writes), and print the
         verifier-drift table against the study's stored verdicts. No EC2.
generate LIVE spend: provision one 1x-L40S box, reconstruct the STOCK vllm args,
         regenerate exactly the whitelisted cells, tear the box down, spool.
lega     Verify the flip2 run's own rows (S3 round trip under the flip2 prefix).
spool    Manual spool of the local run dir (recovery path if generate was cut).

Every flip_probe module constant that names the run is patched here so nothing
can touch the 2026-08-18 flip_nemotron-3-nano-4b data or the study's scaling_*
prefix.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import sys
from pathlib import Path

REPO = Path("/workspace/SmolBench")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

R5 = Path(os.environ.get("R5_DIR", str(Path(__file__).resolve().parent)))

import flip_probe as fp  # noqa: E402
from smolbench.deduction.lean import runner  # noqa: E402

# --- rename EVERYTHING that identifies this run (advisor gate: _spool_flip_run
# derives its S3 dest prefix from FLIP_RUN_NAME) -------------------------------
fp.FLIP_RUN_NAME = "flip2_nemotron-3-nano-4b"
fp.EC2_TAG = "flip2-nemotron-3-nano-4b"
fp.EC2_STATE_FILE_NAME = ".ec2_state_flip2_nemotron-3-nano-4b.json"
fp.N_SAMPLE = 200
# Capacity-pool override: two consecutive us-east-2 g6e.4xlarge spot reclaims on
# 2026-08-21 (i-0d8cdce6 at ~13:50, i-0a10fa46 at ~14:50). All these types carry
# exactly ONE L40S and EC2_REQUIRE_GPU=L40S:1 enforces it at serve time, so
# switching pool does not change the served hardware class.
fp.EC2_INSTANCE_TYPE = os.environ.get("R5_TYPES", fp.EC2_INSTANCE_TYPE)


def _setup() -> None:
    run_dir = fp._flip_run_dir()
    run_dir.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(R5 / "whitelist_new.json", run_dir / "whitelist.json")
    man = json.loads((R5 / "sample_manifest_new.json").read_text())
    man["sha256"] = man["sha256_new"]
    man["flip_run"] = fp.FLIP_RUN_NAME
    (run_dir / "sample_manifest.json").write_text(json.dumps(man, indent=2) + "\n")
    wl = runner.load_cell_whitelist(str(run_dir / "whitelist.json"))
    assert runner.hash_cell_keys(sorted(wl)) == man["sha256"], "whitelist sha mismatch"
    print(f"setup: {run_dir} <- {len(wl)} cells, sha={man['sha256']}")


def _legb(args: argparse.Namespace) -> None:
    """Leg (b) only: reverify the study's ORIGINAL candidates, local-only."""
    lvr = fp._load_lean_verify_rows()
    lvr.require_py312()
    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        lvr.check_workers(args.workers, meminfo.read_text())

    run_dir = fp._flip_run_dir()
    whitelist = runner.load_cell_whitelist(str(fp._whitelist_path()))

    from smolbench.evals import _aws

    real_client = _aws.fresh_client("s3", lvr.S3_REGION)
    study_key = f"{fp.SPOOL_PREFIX}/{fp.STUDY_RUN_NAME}/{lvr.VERIFIED_FILENAME}"
    logging.info("legb: READ-ONLY fetch s3://%s/%s", fp.SPOOL_BUCKET, study_key)
    obj = real_client.get_object(Bucket=fp.SPOOL_BUCKET, Key=study_key)
    study_rows = [
        json.loads(l) for l in obj["Body"].read().decode("utf-8").splitlines() if l.strip()
    ]
    originals = fp._prepare_originals_rows(study_rows, whitelist)

    originals_dir = fp._originals_dir()
    originals_dir.mkdir(parents=True, exist_ok=True)
    rows_path = originals_dir / "originals_all_rows.jsonl"
    new_bytes = "".join(
        json.dumps(r, ensure_ascii=False) + "\n" for r in originals
    ).encode("utf-8")
    scratch_rows = originals_dir / "_scratch" / lvr.ROWS_FILENAME
    no_resume = scratch_rows.exists() and scratch_rows.read_bytes() != new_bytes
    rows_path.write_bytes(new_bytes)
    verified_path = originals_dir / lvr.VERIFIED_FILENAME

    local_client = fp._LocalRunClient(
        rows_path=rows_path, verified_path=verified_path,
        rows_filename=lvr.ROWS_FILENAME, verified_filename=lvr.VERIFIED_FILENAME,
    )
    with lvr._dojo_cache_lock():
        rc = lvr.verify_run(
            client=local_client, bucket="local-originals-rerun", key_prefix="",
            run="_scratch", workers=args.workers, workdir=originals_dir,
            no_resume=no_resume,
        )
    if rc != 0:
        raise SystemExit(f"legb: verify_run rc={rc}")
    _drift_report(verified_path)


def _drift_report(verified_path: Path) -> None:
    import collections

    rows = [json.loads(l) for l in verified_path.read_text().splitlines() if l.strip()]
    by_key = fp.dedupe_rows_earliest_wins(rows)
    pairs = {k: (r.get("_study_verdict", ""), r.get("verdict", "")) for k, r in by_key.items()}
    drift = fp.verifier_drift_stats(pairs)
    verdicts = collections.Counter(v for _, v in pairs.values())
    out = {
        "n": drift["n"], "agree": drift["agree"],
        "agreement_rate": drift["agreement_rate"],
        "reverified_verdict_counts": dict(verdicts),
        "disagreements": drift["disagreements"][:20],
    }
    (R5 / "drift_gate_legb.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))
    exc = verdicts.get("exception", 0)
    print(f"\nDRIFT GATE: {drift['agree']}/{drift['n']} agree; exception verdicts={exc}")
    if drift["n"] and exc / drift["n"] > 0.5:
        raise SystemExit(
            "DRIFT GATE FAILED: verdicts degenerated to 'exception' (the dead-token "
            "signature). STOP -- do not provision."
        )


def _generate(args: argparse.Namespace) -> None:
    ns = argparse.Namespace(regions=args.regions)
    fp._stage_generate(ns)


def _lega(args: argparse.Namespace) -> None:
    lvr = fp._load_lean_verify_rows()
    lvr.require_py312()
    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        lvr.check_workers(args.workers, meminfo.read_text())
    from smolbench.evals import _aws

    real_client = _aws.fresh_client("s3", lvr.S3_REGION)
    with lvr._dojo_cache_lock():
        rc = lvr.verify_run(
            client=real_client, bucket=fp.SPOOL_BUCKET, key_prefix=fp.SPOOL_PREFIX,
            run=fp.FLIP_RUN_NAME, workers=args.workers,
            workdir=fp._flip_run_dir().parent,
        )
    if rc != 0:
        raise SystemExit(f"lega: verify_run rc={rc}")
    print("lega: done ->", fp._flip_run_dir() / fp.VERIFIED_FILENAME)


def _analyze(args: argparse.Namespace) -> None:
    """flip_probe's OWN analyze, on the flip2 run -- gives the unit-tested flip
    stats plus the empty-candidate_proof transport-fault guard."""
    fp._stage_analyze(argparse.Namespace())


def _spool(args: argparse.Namespace) -> None:
    n = fp._spool_flip_run(fp._flip_run_dir())
    print(f"spooled {n} file(s) to s3://{fp.SPOOL_BUCKET}/{fp.SPOOL_PREFIX}/{fp.FLIP_RUN_NAME}/")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["setup", "legb", "generate", "lega", "spool", "analyze"])
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--regions", default="us-west-2,us-east-2,us-east-1")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    {"setup": lambda a: _setup(), "legb": _legb, "generate": _generate,
     "lega": _lega, "spool": _spool, "analyze": _analyze}[args.cmd](args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
