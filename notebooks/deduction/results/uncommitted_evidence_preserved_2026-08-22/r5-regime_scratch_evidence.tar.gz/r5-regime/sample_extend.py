"""Draw the DISJOINT extension sample for the regime-mean experiment.

Reproduces flip_probe's original Random(0) 200-cell draw from the study
lane's 711-cell Mathlib-measurable population (hard-gated on the recorded
sha256 bf22495e...), then CONTINUES the same Random(0) stream to draw
N_NEW further cells from the 511 that remain. Sequential SRS without
replacement: the union of the two draws is itself a simple random sample
of (200 + N_NEW) from the 711, so the legs pool exactly.

Read-only w.r.t. S3 and w.r.t. the existing flip run directory.
"""
from __future__ import annotations

import json
import os
import random
import sys
from pathlib import Path

REPO = Path("/workspace/SmolBench")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

import flip_probe as fp  # noqa: E402
from smolbench.deduction.lean import runner  # noqa: E402
from smolbench.evals import _aws  # noqa: E402

OUT = Path(os.environ["R5_DIR"])
N_NEW = int(os.environ.get("R5_N_NEW", "240"))
OLD_SHA = "bf22495ee0b0a015d4a2c4a050403026fad9c57a636552c7f15058e081b863a4"

key = f"{fp.SPOOL_PREFIX}/{fp.STUDY_RUN_NAME}/{fp.VERIFIED_FILENAME}"
client = _aws.fresh_client("s3", fp.SPOOL_REGION)
body = client.get_object(Bucket=fp.SPOOL_BUCKET, Key=key)["Body"].read()
rows = [json.loads(l) for l in body.decode("utf-8").splitlines() if l.strip()]
cell_rows = [r for r in rows if r.get("kind") == "cell"]
models = {r.get("model") for r in cell_rows}
assert models == {fp.MODEL}, models

measurable = fp.measurable_cell_keys(cell_rows)
print(f"rows={len(rows)} cell_rows={len(cell_rows)} measurable={len(measurable)}")
fp.assert_population_size(measurable, fp.EXPECTED_MATHLIB_POPULATION)

rng = random.Random(fp.SAMPLE_SEED)
old = rng.sample(list(measurable), fp.N_SAMPLE)
old_sorted = sorted(old)
old_sha = runner.hash_cell_keys(old_sorted)
print(f"reproduced old draw sha256={old_sha}")
if old_sha != OLD_SHA:
    raise SystemExit(
        f"GATE FAIL: reproduced 200-cell draw sha {old_sha} != recorded {OLD_SHA}. "
        "The population or its ordering has shifted; do NOT extend."
    )

remaining = sorted(set(measurable) - set(old))
assert len(remaining) == len(measurable) - fp.N_SAMPLE
new = rng.sample(remaining, N_NEW)          # continues the SAME Random(0) stream
new_sorted = sorted(new)
assert not (set(new_sorted) & set(old_sorted))

wl_path = OUT / "whitelist_new.json"
wl_path.write_text(json.dumps([list(k) for k in new_sorted], indent=2) + "\n")
manifest = {
    "n_new": len(new_sorted),
    "n_old": len(old_sorted),
    "seed": fp.SAMPLE_SEED,
    "draw": "Random(0): sample(pop,200) then sample(pop-200,N_NEW) -- continued stream",
    "sha256_new": runner.hash_cell_keys(new_sorted),
    "sha256_old_reproduced": old_sha,
    "study_run": fp.STUDY_RUN_NAME,
    "study_s3_uri": f"s3://{fp.SPOOL_BUCKET}/{key}",
    "n_measurable_mathlib_population": len(measurable),
    "n_rows_downloaded": len(rows),
    "n_cell_rows_downloaded": len(cell_rows),
    "drawn_at_utc": fp._utc_now_iso(),
}
(OUT / "sample_manifest_new.json").write_text(json.dumps(manifest, indent=2) + "\n")
import collections
th = collections.Counter(k[1] for k in new_sorted)
print(json.dumps(manifest, indent=2))
print(f"new: {len(new_sorted)} cells over {len(th)} theorems; "
      f"rungs={dict(collections.Counter(k[3] for k in new_sorted))}")
print(f"overlap with old = {len(set(new_sorted) & set(old_sorted))}")
