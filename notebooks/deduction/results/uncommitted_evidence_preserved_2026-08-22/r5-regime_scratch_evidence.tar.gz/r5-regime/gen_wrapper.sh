#!/bin/bash
# Delay the LOCAL Dojo-using part of generation until leg (b) has released RAM:
# provisioning (~15 min) needs no Dojo, so start the clock now and let the
# sweep begin as leg (b) finishes.
sleep 480
exec /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime/run_generate.sh
