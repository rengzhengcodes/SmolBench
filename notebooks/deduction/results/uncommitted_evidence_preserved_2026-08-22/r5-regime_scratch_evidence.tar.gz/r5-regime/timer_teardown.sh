#!/bin/bash
sleep 7560
. /tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime/env.sh
for r in us-west-2 us-east-2 us-east-1; do
  ids=$(aws ec2 describe-instances --region $r \
    --filters "Name=instance-state-name,Values=pending,running,stopping,stopped" \
              "Name=tag:Experiment,Values=flip2-nemotron-3-nano-4b" \
    --query "Reservations[].Instances[].InstanceId" --output text)
  echo "$r: [$ids]"
  if [ -n "$ids" ]; then aws ec2 terminate-instances --region $r --instance-ids $ids; fi
done
date -u
