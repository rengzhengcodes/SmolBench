#!/bin/bash
sleep 5100
pkill -INT -f "r5_driver.py generate"
sleep 120
pkill -KILL -f "r5_driver.py generate"
echo "HARD CUT DONE $(date -u)"
