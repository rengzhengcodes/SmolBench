"""Pooled regime-mean analysis: leg 1 (2026-08-18, n=200) + leg 2 (this run).

Each leg pairs, per cell, the STUDY process's verdict (re-verified today) against
a RERUN process's verdict (graded by the same verifier in the same pass), so
verifier drift cannot leak into the contrast.

Reports per leg and pooled: a/b/c/d, flip rate (b+c)/n with Clopper-Pearson CI,
mean pass@1 shift (c-b)/n with a naive normal SE and an exact McNemar p, and a
THEOREM-CLUSTER bootstrap CI (cells of one theorem resampled together).
"""
from __future__ import annotations

import collections
import json
import math
import random
import sys
from pathlib import Path

REPO = Path("/workspace/SmolBench")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))
import flip_probe as fp  # noqa: E402
from smolbench.deduction.lean import runner  # noqa: E402

RUNS = REPO / "notebooks/deduction/results/runs"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
B = 20000


def _rows(p: Path) -> list[dict]:
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


def dedupe_prefer_nonexception(rows):
    """EARLIEST-wins among SURVIVING rows -- the study loader's rule.

    flip_probe.dedupe_rows_earliest_wins keeps the first row of any kind, which
    on 2026-08-21 would have let a spot-interruption `exception` row (prompt
    tokens 0, no candidate) mask the real generation that replaced it, scoring
    that cell as a rerun FAIL and inflating b. Exception rows are kept only when
    a cell has nothing else.
    """
    first_good, first_any = {}, {}
    for row in rows:
        if row.get("kind") != "cell":
            continue
        key = runner._row_key(
            row.get("model", ""), row.get("theorem_id", ""), int(row.get("k", -1)),
            row.get("rung", ""), int(row.get("replicate_idx", -1)),
        )
        first_any.setdefault(key, row)
        if row.get("verdict") != "exception":
            first_good.setdefault(key, row)
    return {k: first_good.get(k, v) for k, v in first_any.items()}


def load_leg(run: str) -> tuple[dict, dict]:
    d = RUNS / run
    orig = fp.dedupe_rows_earliest_wins(_rows(d / "originals_rerun" / "verified_rows.jsonl"))
    rerun = dedupe_prefer_nonexception(_rows(d / "verified_rows.jsonl"))
    wl = sorted(runner.load_cell_whitelist(str(d / "whitelist.json")))
    pairs, drift, missing = {}, {}, []
    for k in wl:
        o, r = orig.get(k), rerun.get(k)
        if o is None or r is None:
            missing.append(k)
            continue
        if r.get("verdict") == "exception":
            missing.append(k)      # infrastructure, not a measurement
            continue
        pairs[k] = (o.get("verdict", ""), r.get("verdict", ""))
        drift[k] = (o.get("_study_verdict", ""), o.get("verdict", ""))

    # COMPLETE-THEOREM rule: if a sweep was cut short, whole theorems finish or
    # do not, but a partially-finished theorem contributes only its CHEAP rungs
    # (they are generated first), which would bias the rung mix. Drop any
    # theorem with a missing whitelisted cell. No-op when nothing is missing.
    dropped_theorems = sorted({k[1] for k in missing})
    if dropped_theorems:
        ds = set(dropped_theorems)
        pairs = {k: v for k, v in pairs.items() if k[1] not in ds}
        drift = {k: v for k, v in drift.items() if k[1] not in ds}

    # Transport-fault guard (flip_probe._stage_analyze's own check): streaming is
    # deliberately OFF at max_tokens=32768, so an empty candidate_proof with
    # prompt_tokens > 0 is the delivery-fault signature and would read as a
    # genuine fail on the rerun side.
    empty = {"prompt_tokens_gt_0": 0, "prompt_tokens_0": 0}
    for k in pairs:
        rr = rerun.get(k) or {}
        if not (rr.get("candidate_proof") or "").strip():
            empty["prompt_tokens_gt_0" if int(rr.get("prompt_tokens") or 0) > 0
                  else "prompt_tokens_0"] += 1
    return {"pairs": pairs, "drift": drift, "missing": missing,
            "dropped_theorems": dropped_theorems, "empty_rerun_candidate_proof": empty,
            "n_whitelist": len(wl)}, d


def cells(pairs):
    """-> list of (theorem, b_indicator, c_indicator)."""
    out = []
    for k, (ov, rv) in pairs.items():
        op, rp = fp.is_pass(ov), fp.is_pass(rv)
        out.append((k[1], int(op and not rp), int(rp and not op)))
    return out


def _mcnemar_exact(b: int, c: int) -> float:
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(0, k + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def stats(pairs: dict, seed: int = 12345) -> dict:
    cl = cells(pairs)
    n = len(cl)
    b = sum(x[1] for x in cl)
    c = sum(x[2] for x in cl)
    a = sum(1 for k, (ov, rv) in pairs.items() if fp.is_pass(ov) and fp.is_pass(rv))
    d = n - a - b - c
    flip = (b + c) / n if n else float("nan")
    shift = (c - b) / n if n else float("nan")
    var = ((b + c) - (c - b) ** 2 / n) / n ** 2 if n else float("nan")
    se = math.sqrt(max(var, 0.0))
    lo, hi = fp.clopper_pearson_interval(b + c, n) if n else (float("nan"),) * 2

    # theorem-cluster bootstrap
    by_th = collections.defaultdict(list)
    for th, bi, ci in cl:
        by_th[th].append((bi, ci))
    ths = sorted(by_th)
    rng = random.Random(seed)
    sh, fl = [], []
    for _ in range(B):
        tb = tc = tn = 0
        for _ in range(len(ths)):
            for bi, ci in by_th[ths[rng.randrange(len(ths))]]:
                tb += bi
                tc += ci
                tn += 1
        if tn:
            sh.append((tc - tb) / tn)
            fl.append((tb + tc) / tn)
    sh.sort()
    fl.sort()
    q = lambda v, p: v[max(0, min(len(v) - 1, int(round(p * (len(v) - 1)))))]  # noqa: E731
    boot_se = (sum((x - shift) ** 2 for x in sh) / len(sh)) ** 0.5 if sh else float("nan")
    return {
        "n": n, "n_theorems": len(ths), "a_both_pass": a, "b_orig_pass_rerun_fail": b,
        "c_orig_fail_rerun_pass": c, "d_both_fail": d, "discordant": b + c,
        "pass1_orig": (a + b) / n, "pass1_rerun": (a + c) / n,
        "flip_rate": flip, "flip_rate_cp_ci95": [lo, hi],
        "mean_shift_pts": 100 * shift,
        "mean_shift_se_naive_pts": 100 * se,
        "mean_shift_ci95_naive_pts": [100 * (shift - 1.96 * se), 100 * (shift + 1.96 * se)],
        "mcnemar_exact_p": _mcnemar_exact(b, c),
        "mean_shift_boot_se_pts": 100 * boot_se,
        "mean_shift_ci95_cluster_boot_pts": [100 * q(sh, 0.025), 100 * q(sh, 0.975)],
        "flip_rate_ci95_cluster_boot": [q(fl, 0.025), q(fl, 0.975)],
        "deff_cluster_vs_naive": (boot_se / se) ** 2 if se else float("nan"),
        "mde80_naive_pts": 100 * 2.802 * se,
        "mde80_cluster_pts": 100 * 2.802 * boot_se,
    }


def drift_stats(drift: dict) -> dict:
    ds = fp.verifier_drift_stats(drift)
    vc = collections.Counter(v for _, v in drift.values())
    return {"n": ds["n"], "agree": ds["agree"], "agreement_rate": ds["agreement_rate"],
            "reverified_verdict_counts": dict(vc),
            "disagreements": ds["disagreements"][:10]}


def main() -> None:
    legs = {}
    for name, run in (("leg1_2026-08-18", "flip_nemotron-3-nano-4b"),
                      ("leg2_2026-08-21", "flip2_nemotron-3-nano-4b")):
        d = RUNS / run
        if not (d / "verified_rows.jsonl").exists() or not (
            d / "originals_rerun" / "verified_rows.jsonl"
        ).exists():
            print(f"skip {name}: incomplete")
            continue
        leg, _ = load_leg(run)
        legs[name] = leg

    report = {"legs": {}, "pooled": None}
    for name, leg in legs.items():
        report["legs"][name] = {
            "run": name, "n_whitelist": leg["n_whitelist"],
            "n_missing": len(leg["missing"]),
            "missing": [list(k) for k in leg["missing"][:20]],
            "n_theorems_dropped_incomplete": len(leg["dropped_theorems"]),
            "empty_rerun_candidate_proof": leg["empty_rerun_candidate_proof"],
            "flip": stats(leg["pairs"]),
            "verifier_drift": drift_stats(leg["drift"]),
        }
    if len(legs) > 1:
        pooled_pairs, pooled_drift = {}, {}
        for i, leg in enumerate(legs.values()):
            for k, v in leg["pairs"].items():
                pooled_pairs[(i,) + k] = v
            for k, v in leg["drift"].items():
                pooled_drift[(i,) + k] = v
        # cluster key = (leg, theorem); cells() reads index 1 of the key
        pooled_cells = {(k[0], k[2], k[3], k[4], k[5]): v for k, v in pooled_pairs.items()}
        report["pooled"] = {
            "flip": stats(pooled_cells),
            "verifier_drift": drift_stats(pooled_drift),
        }
        s1 = report["legs"]["leg1_2026-08-18"]["flip"]
        s2 = report["legs"]["leg2_2026-08-21"]["flip"]
        d = s1["mean_shift_pts"] - s2["mean_shift_pts"]
        sed = math.hypot(s1["mean_shift_boot_se_pts"], s2["mean_shift_boot_se_pts"])
        report["leg_heterogeneity"] = {
            "shift_diff_pts": d, "se_pts": sed,
            "z": d / sed if sed else float("nan"),
        }
    (OUT / "regime_mean_report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
