set -a
. /workspace/SmolBench/notebooks/deduction/keys.env
. /workspace/SmolBench/notebooks/ec2-operator.env
set +a
unset GITHUB_ACCESS_TOKEN
export R5_DIR=/tmp/claude-1001/-workspace-SmolBench/e02d645d-a971-4770-ad99-4f84f96cc96e/scratchpad/r5-regime
export PATH="$HOME/.elan/bin:$PATH"
